package exercise33_09;


import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.input.*;

public class Exercise33_09Server extends Application {
  private TextArea taServer = new TextArea();
  private TextArea taClient = new TextArea();
  DataInputStream inputFromClient = null;
  DataOutputStream outputToClient = null;
 
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
	  	taClient.setWrapText(true);
	    taClient.setDisable(true);
	
	    BorderPane pane1 = new BorderPane();
	    pane1.setTop(new Label("History"));
	    pane1.setCenter(new ScrollPane(taServer));
	    BorderPane pane2 = new BorderPane();
	    pane2.setTop(new Label("New Message"));
	    pane2.setCenter(new ScrollPane(taClient));
	    
	    VBox vBox = new VBox(5);
	    vBox.getChildren().addAll(pane1, pane2);
	
	    // Create a scene and place it in the stage
	    Scene scene = new Scene(vBox, 200, 200);
	    primaryStage.setTitle("Exercise31_09Server"); // Set the stage title
	    primaryStage.setScene(scene); // Place the scene in the stage
	    primaryStage.show(); // Display the stage

	  taServer.setOnKeyPressed(e -> {
	    	if(e.getCode() == KeyCode.ENTER) {
	    		try {
	    			String message = taClient.getText();//get message from text area
	    			outputToClient.writeUTF(message);
	    			outputToClient.flush();//send the message to client
	    			taServer.appendText(message);//append the text on the server
	    		} catch (IOException ex) {
	    			System.err.println(ex);
	    		}
	    	}
	    	});
	  new Thread(() -> {
    	try {
        	ServerSocket socket = new ServerSocket(8000);
				DataInputStream inputFromClient = new DataInputStream(socket.getInputStream());
				DataOutputStream outputToClient = new DataOutputStream(socket.getOutputStream());
			
        	while (true) {
        		String message = inputFromClient.readUTF();//receive message from client**message variable
        		String txt = new String();
        		String message = ((DataInput) outputToClient).readUTF();
        		Platform.runLater(() -> {
                    taServer.appendText("Input received from client: " + message + '\n');
        		
        	)};
    		} catch (IOException e1) {
    			e1.printStackTrace();
			}
        }
    ).start();
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}

